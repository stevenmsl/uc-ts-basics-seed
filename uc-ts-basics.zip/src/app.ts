console.log("Hello TypeScript!");
